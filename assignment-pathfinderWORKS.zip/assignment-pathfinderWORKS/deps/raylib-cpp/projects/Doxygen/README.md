# raylib-cpp Doxygen

The documentation uses the [`doxygen-awesome-css`](https://github.com/jothepro/doxygen-awesome-css) theme.

## Build

To build the documentation with [Doxygen](https://www.doxygen.nl), run the following command from raylib-cpp's root directory.

```sh
git submodule update --init
doxygen projects/Doxygen/Doxyfile
```
